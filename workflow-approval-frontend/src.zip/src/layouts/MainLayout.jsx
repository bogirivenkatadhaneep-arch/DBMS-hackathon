import React from "react";
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  Avatar,
  Stack,
  InputBase,
  IconButton,
  Badge,
} from "@mui/material";
import { Search, NotificationsNone, Menu } from "@mui/icons-material";
import Sidebar from "../components/Sidebar"; // Double check this path matches your project structure

const drawerWidth = 300;

function MainLayout({ children }) {
  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "#f8fafc", width: "100%" }}>
      
      {/* LEFT SIDEBAR PANEL */}
      <Box sx={{ width: drawerWidth, flexShrink: 0 }}>
        <Sidebar />
      </Box>

      {/* RIGHT CONTENT WORKSPACE */}
      <Box 
        sx={{ 
          flexGrow: 1, 
          minWidth: 0, 
          display: "flex", 
          flexDirection: "column",
          ml: `${drawerWidth}px`,
          bgcolor: "#f8fafc"
        }}
      >
        {/* TOP COMPACT GLOBAL HEADER */}
        <AppBar
          position="static"
          elevation={0}
          sx={{
            bgcolor: "#ffffff",
            color: "#1e293b",
            borderBottom: "1px solid #f1f5f9",
          }}
        >
          <Toolbar sx={{ justifyContent: "space-between", px: 4, height: 70 }}>
            <Stack direction="row" alignItems="center" spacing={2} sx={{ flexGrow: 1 }}>
              <IconButton edge="start" color="inherit" sx={{ display: { lg: 'none' } }}>
                <Menu />
              </IconButton>
              
              {/* Perfect Pill Search Bar */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  bgcolor: "#f1f5f9",
                  borderRadius: 2.5,
                  px: 2,
                  py: 0.8,
                  width: 400,
                  border: "1px solid #e2e8f0"
                }}
              >
                <Search sx={{ color: "#94a3b8", fontSize: 20, mr: 1 }} />
                <InputBase
                  placeholder="Search workflows, approvals..."
                  sx={{ 
                    fontSize: "0.875rem", 
                    width: "100%",
                    "& input::placeholder": { color: "#94a3b8", opacity: 1 }
                  }}
                />
                <Typography variant="caption" sx={{ bgcolor: "#fff", color: "#94a3b8", px: 0.8, py: 0.2, borderRadius: 1, border: "1px solid #e2e8f0", fontSize: "0.65rem", fontWeight: 700 }}>
                  ⌘K
                </Typography>
              </Box>
            </Stack>

            {/* Profile Action Tray */}
            <Stack direction="row" alignItems="center" spacing={2.5}>
              <IconButton sx={{ color: "#64748b", bgcolor: "#f8fafc", p: 1, border: "1px solid #e2e8f0", borderRadius: 2 }}>
                <Badge variant="dot" color="error" overlap="circular">
                  <NotificationsNone sx={{ fontSize: 22 }} />
                </Badge>
              </IconButton>

              <Stack direction="row" alignItems="center" spacing={1.5}>
                <Avatar sx={{ width: 36, height: 36, bgcolor: "#e2e8f0", color: "#475569", fontSize: "0.875rem", fontWeight: 600 }}>
                  A
                </Avatar>
                <Typography variant="body2" fontWeight="600" color="#1e293b">
                  Admin User
                </Typography>
              </Stack>
            </Stack>
          </Toolbar>
        </AppBar>

        {/* APPLICATION BODY WRAPPER */}
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: 4,
            width: "100%",
            boxSizing: "border-box"
          }}
        >
          {children}
        </Box>
      </Box>
    </Box>
  );
}

export default MainLayout;