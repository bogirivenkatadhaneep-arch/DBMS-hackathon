import React from "react";
import {
  Box,
  Typography,
  List,
  ListItemButton,
  ListItemText,
  Avatar,
  Stack,
} from "@mui/material";

import {
  Dashboard,
  Assignment,
  AddCircle,
  PendingActions,
  History,
  Search,
  Analytics,
  People,
  Security,
  ReceiptLong,
  Settings,
} from "@mui/icons-material";

import { Link, useLocation } from "react-router-dom";

const menuItems = [
  { text: "Dashboard", icon: <Dashboard />, path: "/dashboard" },
  { text: "Workflows", icon: <Assignment />, path: "/workflows" },
  { text: "Create Workflow", icon: <AddCircle />, path: "/create-workflow" },
  { text: "Pending Approvals", icon: <PendingActions />, path: "/pending-approvals" },
  { text: "Approval History", icon: <History />, path: "/approval-history" },
  { text: "AI Search", icon: <Search />, path: "/ai-search" },
  { text: "Analytics", icon: <Analytics />, path: "/analytics" },
  { text: "Users", icon: <People />, path: "/users" },
  { text: "Roles", icon: <Security />, path: "/roles" },
  { text: "Audit Logs", icon: <ReceiptLong />, path: "/audit-logs" },
  { text: "Settings", icon: <Settings />, path: "/settings" },
];

function Sidebar() {
  const location = useLocation();

  return (
    <Box
      sx={{
        width: 300,
        height: "100vh",
        position: "fixed",
        left: 0,
        top: 0,
        background:
          "linear-gradient(180deg,#081028 0%,#091a46 100%)",
        color: "#fff",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box sx={{ p: 3 }}>
        <Typography variant="h5" fontWeight="bold">
          Workflow Portal
        </Typography>

        <Typography
          variant="body2"
          sx={{ color: "#94a3b8", mt: 0.5 }}
        >
          Approval & Review
        </Typography>
      </Box>

      <List sx={{ px: 2 }}>
        {menuItems.map((item) => (
          <ListItemButton
            key={item.text}
            component={Link}
            to={item.path}
            sx={{
              mb: 1,
              borderRadius: 3,
              color: "#fff",

              background:
                location.pathname === item.path
                  ? "linear-gradient(90deg,#2563eb,#9333ea)"
                  : "transparent",

              "&:hover": {
                background:
                  "linear-gradient(90deg,#2563eb,#9333ea)",
              },
            }}
          >
            <Box sx={{ mr: 2 }}>{item.icon}</Box>

            <ListItemText primary={item.text} />
          </ListItemButton>
        ))}
      </List>

      <Box sx={{ flexGrow: 1 }} />

      <Box
        sx={{
          m: 2,
          p: 2,
          borderRadius: 4,
          background:
            "linear-gradient(135deg,#2563eb,#7c3aed)",
        }}
      >
        <Typography fontWeight="bold">
          AI Assistant
        </Typography>

        <Typography
          variant="body2"
          sx={{ opacity: 0.9 }}
        >
          Ask anything about workflows
        </Typography>
      </Box>

      <Box
        sx={{
          p: 2,
          borderTop: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <Stack direction="row" spacing={2}>
          <Avatar
            sx={{
              bgcolor: "#9333ea",
            }}
          >
            A
          </Avatar>

          <Box>
            <Typography fontWeight="bold">
              Admin User
            </Typography>

            <Typography
              variant="body2"
              sx={{ color: "#94a3b8" }}
            >
              admin@example.com
            </Typography>
          </Box>
        </Stack>
      </Box>
    </Box>
  );
}

export default Sidebar;