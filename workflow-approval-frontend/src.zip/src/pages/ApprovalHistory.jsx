import React from "react";
import {
  Typography,
  Card,
  CardContent,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Chip,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

function ApprovalHistory() {
  const data = [
    {
      id: "WF-101",
      workflow: "Leave Request",
      approver: "HR Manager",
      decision: "Approved",
      date: "14 Jun 2026",
    },
    {
      id: "WF-102",
      workflow: "Budget Approval",
      approver: "Finance Head",
      decision: "Approved",
      date: "13 Jun 2026",
    },
    {
      id: "WF-103",
      workflow: "Hiring Request",
      approver: "Recruitment Lead",
      decision: "Pending",
      date: "12 Jun 2026",
    },
    {
      id: "WF-104",
      workflow: "Travel Reimbursement",
      approver: "Admin Manager",
      decision: "Rejected",
      date: "11 Jun 2026",
    },
  ];

  const getColor = (status) => {
    if (status === "Approved") return "success";
    if (status === "Rejected") return "error";
    return "warning";
  };

  return (
    <MainLayout>
      <Typography
        variant="h4"
        fontWeight="bold"
        mb={3}
      >
        Approval History
      </Typography>

      <Card sx={{ borderRadius: 4 }}>
        <CardContent>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Workflow</TableCell>
                <TableCell>Approver</TableCell>
                <TableCell>Decision</TableCell>
                <TableCell>Date</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {data.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{row.id}</TableCell>
                  <TableCell>{row.workflow}</TableCell>
                  <TableCell>{row.approver}</TableCell>

                  <TableCell>
                    <Chip
                      label={row.decision}
                      color={getColor(row.decision)}
                    />
                  </TableCell>

                  <TableCell>{row.date}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </MainLayout>
  );
}

export default ApprovalHistory;