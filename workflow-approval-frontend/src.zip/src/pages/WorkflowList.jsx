import React from "react";
import {
  Typography,
  Card,
  CardContent,
  TextField,
  InputAdornment,
  Chip,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Box,
} from "@mui/material";

import SearchIcon from "@mui/icons-material/Search";
import MainLayout from "../layouts/MainLayout";

function WorkflowList() {
  const workflows = [
    {
      id: "WF-101",
      title: "Leave Request",
      department: "HR",
      status: "Pending",
      date: "14 Jun 2026",
    },
    {
      id: "WF-102",
      title: "Budget Approval",
      department: "Finance",
      status: "Approved",
      date: "13 Jun 2026",
    },
    {
      id: "WF-103",
      title: "Hiring Request",
      department: "HR",
      status: "Under Review",
      date: "12 Jun 2026",
    },
    {
      id: "WF-104",
      title: "Travel Reimbursement",
      department: "Admin",
      status: "Rejected",
      date: "11 Jun 2026",
    },
    {
      id: "WF-105",
      title: "Laptop Purchase",
      department: "IT",
      status: "Approved",
      date: "10 Jun 2026",
    },
  ];

  const getColor = (status) => {
    switch (status) {
      case "Approved":
        return "success";
      case "Rejected":
        return "error";
      case "Pending":
        return "warning";
      default:
        return "info";
    }
  };

  return (
    <MainLayout>
      <Typography
        variant="h4"
        fontWeight="bold"
        mb={3}
      >
        Workflow List
      </Typography>

      <Card
        sx={{
          borderRadius: 4,
          boxShadow:
            "0 10px 30px rgba(0,0,0,0.08)",
        }}
      >
        <CardContent>
          <Box mb={3}>
            <TextField
              fullWidth
              placeholder="Search workflow..."
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Box>

          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <strong>ID</strong>
                </TableCell>

                <TableCell>
                  <strong>Title</strong>
                </TableCell>

                <TableCell>
                  <strong>Department</strong>
                </TableCell>

                <TableCell>
                  <strong>Status</strong>
                </TableCell>

                <TableCell>
                  <strong>Date</strong>
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {workflows.map((workflow) => (
                <TableRow key={workflow.id}>
                  <TableCell>
                    {workflow.id}
                  </TableCell>

                  <TableCell>
                    {workflow.title}
                  </TableCell>

                  <TableCell>
                    {workflow.department}
                  </TableCell>

                  <TableCell>
                    <Chip
                      label={workflow.status}
                      color={getColor(
                        workflow.status
                      )}
                    />
                  </TableCell>

                  <TableCell>
                    {workflow.date}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </MainLayout>
  );
}

export default WorkflowList;