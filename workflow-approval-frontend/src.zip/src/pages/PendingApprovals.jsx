import React from "react";
import {
  Typography,
  Card,
  CardContent,
  Button,
  Chip,
  Stack,
  Box,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

function PendingApprovals() {
  const approvals = [
    {
      id: "WF-101",
      title: "Leave Request",
      employee: "John Doe",
      department: "HR",
    },
    {
      id: "WF-102",
      title: "Budget Approval",
      employee: "Sarah Smith",
      department: "Finance",
    },
    {
      id: "WF-103",
      title: "Hiring Request",
      employee: "David Lee",
      department: "Recruitment",
    },
  ];

  return (
    <MainLayout>
      <Typography
        variant="h4"
        fontWeight="bold"
        mb={3}
      >
        Pending Approvals
      </Typography>

      {approvals.map((item) => (
        <Card
          key={item.id}
          sx={{
            mb: 3,
            borderRadius: 4,
            boxShadow:
              "0 10px 25px rgba(0,0,0,0.08)",
          }}
        >
          <CardContent>
            <Typography
              variant="h6"
              fontWeight="bold"
            >
              {item.title}
            </Typography>

            <Typography color="text.secondary">
              Workflow ID: {item.id}
            </Typography>

            <Typography color="text.secondary">
              Employee: {item.employee}
            </Typography>

            <Typography color="text.secondary">
              Department: {item.department}
            </Typography>

            <Box mt={2}>
              <Chip
                label="Pending Review"
                color="warning"
              />
            </Box>

            <Stack
              direction="row"
              spacing={2}
              mt={3}
            >
              <Button
                variant="contained"
                color="success"
              >
                Approve
              </Button>

              <Button
                variant="contained"
                color="error"
              >
                Reject
              </Button>
            </Stack>
          </CardContent>
        </Card>
      ))}
    </MainLayout>
  );
}

export default PendingApprovals;