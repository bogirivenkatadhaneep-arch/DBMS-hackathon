import React, { useState } from "react";
import api from "../services/api";

import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  MenuItem,
  Button,
  Stack,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

function CreateWorkflow() {
  const [workflow, setWorkflow] = useState({
    title: "",
    description: "",
    department: "",
    priority: "",
  });

  const handleChange = (e) => {
    setWorkflow({
      ...workflow,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async () => {
    try {
      await api.post("/workflows", {
        title: workflow.title,
        description: workflow.description,
        department: workflow.department,
        priority: workflow.priority,
        status: "Pending",
      });

      alert("Workflow Created Successfully");

      setWorkflow({
        title: "",
        description: "",
        department: "",
        priority: "",
      });
    } catch (error) {
      console.error(error);
      alert("Failed to create workflow");
    }
  };

  return (
    <MainLayout>
      <Typography
        variant="h4"
        fontWeight="bold"
        mb={3}
      >
        Create Workflow
      </Typography>

      <Card
        sx={{
          borderRadius: 4,
          boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
          maxWidth: 1000,
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Stack spacing={3}>
            <TextField
              fullWidth
              label="Workflow Title"
              name="title"
              value={workflow.title}
              onChange={handleChange}
            />

            <TextField
              fullWidth
              multiline
              rows={4}
              label="Description"
              name="description"
              value={workflow.description}
              onChange={handleChange}
            />

            <TextField
              select
              fullWidth
              label="Department"
              name="department"
              value={workflow.department}
              onChange={handleChange}
            >
              <MenuItem value="HR">HR</MenuItem>
              <MenuItem value="Finance">Finance</MenuItem>
              <MenuItem value="IT">IT</MenuItem>
              <MenuItem value="Operations">
                Operations
              </MenuItem>
            </TextField>

            <TextField
              select
              fullWidth
              label="Priority"
              name="priority"
              value={workflow.priority}
              onChange={handleChange}
            >
              <MenuItem value="Low">Low</MenuItem>
              <MenuItem value="Medium">Medium</MenuItem>
              <MenuItem value="High">High</MenuItem>
            </TextField>

            <Box
              sx={{
                display: "flex",
                gap: 2,
                justifyContent: "flex-end",
              }}
            >
              <Button variant="outlined">
                Save Draft
              </Button>

              <Button
                variant="contained"
                onClick={handleSubmit}
              >
                Submit Workflow
              </Button>
            </Box>
          </Stack>
        </CardContent>
      </Card>
    </MainLayout>
  );
}

export default CreateWorkflow;

