import React from "react";
import {
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  Stepper,
  Step,
  StepLabel,
  Divider,
  Box,
  Avatar,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

import {
  Assignment,
  Person,
  Business,
  PriorityHigh,
} from "@mui/icons-material";

function WorkflowDetails() {
  const steps = [
    "Submitted",
    "Reviewer Approved",
    "Manager Approved",
    "Finance Review",
    "HR Approval",
    "Completed",
  ];

  const activeStep = 3;

  return (
    <MainLayout>
      <Typography
        variant="h4"
        fontWeight="bold"
        mb={3}
      >
        Workflow Details
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card sx={{ borderRadius: 4 }}>
            <CardContent>
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                mb={3}
              >
                <Typography
                  variant="h5"
                  fontWeight="bold"
                >
                  Leave Request
                </Typography>

                <Chip
                  label="Pending"
                  color="warning"
                />
              </Box>

              <Divider sx={{ mb: 3 }} />

              <Box
                display="flex"
                alignItems="center"
                gap={2}
                mb={2}
              >
                <Assignment />
                <Typography>
                  Workflow ID: WF-101
                </Typography>
              </Box>

              <Box
                display="flex"
                alignItems="center"
                gap={2}
                mb={2}
              >
                <Business />
                <Typography>
                  Department: HR
                </Typography>
              </Box>

              <Box
                display="flex"
                alignItems="center"
                gap={2}
                mb={2}
              >
                <PriorityHigh />
                <Typography>
                  Priority: High
                </Typography>
              </Box>

              <Box
                display="flex"
                alignItems="center"
                gap={2}
                mb={4}
              >
                <Person />
                <Typography>
                  Requested By: John Doe
                </Typography>
              </Box>

              <Typography
                variant="h6"
                fontWeight="bold"
                mb={2}
              >
                Description
              </Typography>

              <Typography>
                Employee requested leave
                for 5 working days due
                to personal reasons.
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{ borderRadius: 4 }}>
            <CardContent>
              <Typography
                variant="h6"
                fontWeight="bold"
                mb={3}
              >
                Approval Timeline
              </Typography>

              <Stepper
                activeStep={activeStep}
                orientation="vertical"
              >
                {steps.map((step) => (
                  <Step key={step}>
                    <StepLabel>
                      {step}
                    </StepLabel>
                  </Step>
                ))}
              </Stepper>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card sx={{ borderRadius: 4 }}>
            <CardContent>
              <Typography
                variant="h6"
                fontWeight="bold"
                mb={3}
              >
                Approval History
              </Typography>

              <Box mb={2}>
                ✅ Workflow Submitted
                - 11 Jun 2026
              </Box>

              <Box mb={2}>
                ✅ Reviewer Approved
                - 12 Jun 2026
              </Box>

              <Box mb={2}>
                ✅ Manager Approved
                - 13 Jun 2026
              </Box>

              <Box mb={2}>
                ⏳ Finance Review Pending
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card sx={{ borderRadius: 4 }}>
            <CardContent>
              <Typography
                variant="h6"
                fontWeight="bold"
                mb={3}
              >
                Assigned Approvers
              </Typography>

              <Box
                display="flex"
                gap={3}
                flexWrap="wrap"
              >
                <Box textAlign="center">
                  <Avatar
                    sx={{
                      width: 60,
                      height: 60,
                      mx: "auto",
                    }}
                  >
                    R
                  </Avatar>

                  <Typography mt={1}>
                    Reviewer
                  </Typography>
                </Box>

                <Box textAlign="center">
                  <Avatar
                    sx={{
                      width: 60,
                      height: 60,
                      mx: "auto",
                    }}
                  >
                    M
                  </Avatar>

                  <Typography mt={1}>
                    Manager
                  </Typography>
                </Box>

                <Box textAlign="center">
                  <Avatar
                    sx={{
                      width: 60,
                      height: 60,
                      mx: "auto",
                    }}
                  >
                    F
                  </Avatar>

                  <Typography mt={1}>
                    Finance
                  </Typography>
                </Box>

                <Box textAlign="center">
                  <Avatar
                    sx={{
                      width: 60,
                      height: 60,
                      mx: "auto",
                    }}
                  >
                    H
                  </Avatar>

                  <Typography mt={1}>
                    HR
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </MainLayout>
  );
}

export default WorkflowDetails;