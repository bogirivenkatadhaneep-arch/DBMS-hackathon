import React from "react";
import {
Box,
Card,
Grid,
Typography,
TextField,
Button,
Checkbox,
FormControlLabel,
InputAdornment,
Divider,
} from "@mui/material";

import {
EmailOutlined,
LockOutlined,
VisibilityOutlined,
AccountBalanceOutlined,
SendOutlined,
TaskAltOutlined,
ShieldOutlined,
AutoAwesomeOutlined,
BarChartOutlined,
Lock,
} from "@mui/icons-material";

import { useNavigate } from "react-router-dom";

function Login() {
const navigate = useNavigate();

const features = [
{
icon: <SendOutlined />,
title: "Workflow Submission",
desc: "Submit and manage workflow requests with ease",
},
{
icon: <TaskAltOutlined />,
title: "Approval Tracking",
desc: "Track approval progress in real-time across all levels",
},
{
icon: <ShieldOutlined />,
title: "Audit History",
desc: "Complete audit trail and history for compliance",
},
{
icon: <AutoAwesomeOutlined />,
title: "AI Semantic Search",
desc: "Intelligent search across documents and workflows",
},
{
icon: <BarChartOutlined />,
title: "Analytics Dashboard",
desc: "Data-driven insights and performance analytics",
},
];

return (
<Box
sx={{
minHeight: "100vh",
background:
"radial-gradient(circle at top left, #334155 0%, #0f172a 45%, #020617 100%)",
display: "flex",
justifyContent: "center",
alignItems: "center",
p: 3,
}}
>
<Card
sx={{
width: "100%",
maxWidth: 1150,
borderRadius: "28px",
overflow: "hidden",
boxShadow: "0 25px 80px rgba(0,0,0,0.55)",
}}
> <Grid container>
{/* LEFT PANEL */}
<Grid
size={{ xs: 12, md: 6 }}
sx={{
position: "relative",
background:
"linear-gradient(135deg,#0f172a,#020617,#1e1b4b)",
color: "white",
p: 5,
overflow: "hidden",
}}
>
<Box
sx={{
position: "absolute",
width: 350,
height: 350,
background:
"radial-gradient(circle, rgba(139,92,246,.5), transparent)",
bottom: -120,
left: -100,
}}
/>

```
        <Typography
          sx={{
            fontSize: "52px",
            fontWeight: 800,
            background:
              "linear-gradient(90deg,#ffffff,#8b5cf6)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            mb: 2,
          }}
        >
          W
        </Typography>

        <Typography
          variant="h3"
          fontWeight="bold"
          gutterBottom
        >
          Workflow Approval Portal
        </Typography>

        <Typography
          sx={{
            color: "#cbd5e1",
            mb: 5,
            fontSize: "1.15rem",
          }}
        >
          Multi-Level Approvals with AI-Powered
          Semantic Search
        </Typography>

        <Divider
          sx={{
            width: 60,
            borderColor: "#3b82f6",
            mb: 4,
          }}
        />

        {features.map((item, index) => (
          <Box
            key={index}
            sx={{
              display: "flex",
              gap: 2,
              mb: 3,
              alignItems: "flex-start",
            }}
          >
            <Box
              sx={{
                width: 48,
                height: 48,
                borderRadius: "50%",
                background:
                  "rgba(99,102,241,0.2)",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {item.icon}
            </Box>

            <Box>
              <Typography
                fontWeight={700}
                sx={{ mb: 0.5 }}
              >
                {item.title}
              </Typography>

              <Typography
                variant="body2"
                sx={{
                  color: "#cbd5e1",
                }}
              >
                {item.desc}
              </Typography>
            </Box>
          </Box>
        ))}
      </Grid>

      {/* RIGHT PANEL */}
      <Grid
        size={{ xs: 12, md: 6 }}
        sx={{
          background: "#ffffff",
          p: 6,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            mb: 3,
          }}
        >
          <Box
            sx={{
              width: 90,
              height: 90,
              borderRadius: "50%",
              background: "#ede9fe",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Lock
              sx={{
                color: "#6366f1",
                fontSize: 40,
              }}
            />
          </Box>
        </Box>

        <Typography
          align="center"
          variant="h3"
          fontWeight="bold"
        >
          Welcome Back
        </Typography>

        <Typography
          align="center"
          color="text.secondary"
          sx={{ mb: 4 }}
        >
          Sign in to continue to your account
        </Typography>

        <TextField
          fullWidth
          placeholder="Email Address"
          sx={{ mb: 3 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <EmailOutlined />
              </InputAdornment>
            ),
          }}
        />

        <TextField
          fullWidth
          type="password"
          placeholder="Password"
          sx={{ mb: 2 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockOutlined />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                <VisibilityOutlined />
              </InputAdornment>
            ),
          }}
        />

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 3,
          }}
        >
          <FormControlLabel
            control={<Checkbox />}
            label="Remember me"
          />

          <Typography
            sx={{
              color: "#6366f1",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            Forgot password?
          </Typography>
        </Box>

        <Button
          fullWidth
          onClick={() => navigate("/dashboard")}
          sx={{
            py: 1.8,
            color: "white",
            fontWeight: "bold",
            borderRadius: "12px",
            background:
              "linear-gradient(90deg,#2563eb,#7c3aed)",
            mb: 3,
          }}
        >
          SIGN IN
        </Button>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 2,
            mb: 3,
          }}
        >
          <Divider sx={{ flex: 1 }} />
          <Typography>OR</Typography>
          <Divider sx={{ flex: 1 }} />
        </Box>

        <Button
          fullWidth
          variant="outlined"
          startIcon={<AccountBalanceOutlined />}
          sx={{
            py: 1.5,
            borderRadius: "12px",
          }}
        >
          Sign in with SSO
        </Button>

        <Typography
          align="center"
          sx={{
            mt: 5,
            color: "#64748b",
          }}
        >
          Workflow Approval & Review Portal
        </Typography>
      </Grid>
    </Grid>
  </Card>
</Box>
);
}

export default Login;
