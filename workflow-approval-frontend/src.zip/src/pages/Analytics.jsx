import React from "react";
import {
Grid,
Card,
CardContent,
Typography,
Box,
Avatar,
LinearProgress,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

import {
TrendingUp,
CheckCircle,
PendingActions,
Cancel,
} from "@mui/icons-material";

import {
ResponsiveContainer,
BarChart,
Bar,
XAxis,
YAxis,
Tooltip,
PieChart,
Pie,
Cell,
LineChart,
Line,
} from "recharts";

function Analytics() {
const monthlyData = [
{ month: "Jan", value: 25 },
{ month: "Feb", value: 40 },
{ month: "Mar", value: 55 },
{ month: "Apr", value: 38 },
{ month: "May", value: 70 },
{ month: "Jun", value: 90 },
];

const departmentData = [
{ dept: "HR", requests: 40 },
{ dept: "Finance", requests: 55 },
{ dept: "IT", requests: 70 },
{ dept: "Admin", requests: 35 },
];

const pieData = [
{ name: "Approved", value: 180 },
{ name: "Pending", value: 32 },
{ name: "Rejected", value: 33 },
];

const COLORS = [
"#22c55e",
"#f59e0b",
"#ef4444",
];

const stats = [
{
title: "Total Workflows",
value: "245",
icon: <TrendingUp />,
color: "#2563eb",
},
{
title: "Approved",
value: "180",
icon: <CheckCircle />,
color: "#22c55e",
},
{
title: "Pending",
value: "32",
icon: <PendingActions />,
color: "#f59e0b",
},
{
title: "Rejected",
value: "33",
icon: <Cancel />,
color: "#ef4444",
},
];

return ( <MainLayout> <Typography
     variant="h4"
     fontWeight="bold"
     mb={1}
   >
Analytics Dashboard </Typography>

```
  <Typography
    color="text.secondary"
    mb={4}
  >
    Approval trends, workflow metrics and
    department performance.
  </Typography>

  <Grid container spacing={3}>
    {stats.map((item) => (
      <Grid item xs={12} md={3} key={item.title}>
        <Card sx={{ borderRadius: 4 }}>
          <CardContent>
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
            >
              <Box>
                <Typography color="text.secondary">
                  {item.title}
                </Typography>

                <Typography
                  variant="h3"
                  fontWeight="bold"
                >
                  {item.value}
                </Typography>
              </Box>

              <Avatar
                sx={{
                  bgcolor: item.color,
                }}
              >
                {item.icon}
              </Avatar>
            </Box>
          </CardContent>
        </Card>
      </Grid>
    ))}

    <Grid item xs={12} md={8}>
      <Card sx={{ borderRadius: 4 }}>
        <CardContent>
          <Typography
            variant="h6"
            mb={2}
          >
            Monthly Approvals
          </Typography>

          <ResponsiveContainer
            width="100%"
            height={300}
          >
            <LineChart data={monthlyData}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#2563eb"
                strokeWidth={3}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </Grid>

    <Grid item xs={12} md={4}>
      <Card sx={{ borderRadius: 4 }}>
        <CardContent>
          <Typography
            variant="h6"
            mb={2}
          >
            Workflow Status
          </Typography>

          <ResponsiveContainer
            width="100%"
            height={280}
          >
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                outerRadius={90}
              >
                {pieData.map(
                  (entry, index) => (
                    <Cell
                      key={index}
                      fill={
                        COLORS[index]
                      }
                    />
                  )
                )}
              </Pie>

              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </Grid>

    <Grid item xs={12} md={7}>
      <Card sx={{ borderRadius: 4 }}>
        <CardContent>
          <Typography
            variant="h6"
            mb={2}
          >
            Department Requests
          </Typography>

          <ResponsiveContainer
            width="100%"
            height={300}
          >
            <BarChart data={departmentData}>
              <XAxis dataKey="dept" />
              <YAxis />
              <Tooltip />
              <Bar
                dataKey="requests"
                fill="#7c3aed"
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </Grid>

    <Grid item xs={12} md={5}>
      <Card sx={{ borderRadius: 4 }}>
        <CardContent>
          <Typography
            variant="h6"
            mb={3}
          >
            Performance Metrics
          </Typography>

          <Typography>
            Approval Rate
          </Typography>
          <LinearProgress
            variant="determinate"
            value={85}
            sx={{ mb: 3 }}
          />

          <Typography>
            Processing Speed
          </Typography>
          <LinearProgress
            variant="determinate"
            value={78}
            sx={{ mb: 3 }}
          />

          <Typography>
            SLA Compliance
          </Typography>
          <LinearProgress
            variant="determinate"
            value={92}
          />
        </CardContent>
      </Card>
    </Grid>
  </Grid>
</MainLayout>

);
}

export default Analytics;
