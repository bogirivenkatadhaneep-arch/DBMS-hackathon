import React from "react";
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Avatar,
  Chip,
  Stack,
  Button,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

import {
  Assignment,
  PendingActions,
  CheckCircle,
  Cancel,
  AccessTime,
  ChevronRight,
  CalendarToday,
} from "@mui/icons-material";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from "recharts";

function Dashboard() {
  const stats = [
    {
      title: "Total Workflows",
      value: "245",
      subtext: "All time workflows",
      icon: <Assignment sx={{ color: "#7c3aed", fontSize: 22 }} />,
      bgColor: "#f3e8ff",
      growth: "↑ 12% from last month",
      growthColor: "#22c55e",
    },
    {
      title: "Pending Approvals",
      value: "32",
      subtext: "Awaiting your action",
      icon: <PendingActions sx={{ color: "#ea580c", fontSize: 22 }} />,
      bgColor: "#ffedd5",
      growth: "↑ 8% from last month",
      growthColor: "#ea580c",
    },
    {
      title: "Approved",
      value: "180",
      subtext: "Successfully approved",
      icon: <CheckCircle sx={{ color: "#16a34a", fontSize: 22 }} />,
      bgColor: "#dcfce7",
      growth: "↑ 15% from last month",
      growthColor: "#22c55e",
    },
    {
      title: "Rejected",
      value: "33",
      subtext: "This period",
      icon: <Cancel sx={{ color: "#dc2626", fontSize: 22 }} />,
      bgColor: "#fee2e2",
      growth: "↓ 5% from last month",
      growthColor: "#ef4444",
    },
  ];

  const trendData = [
    { month: "Mar", value: 35 },
    { month: "Apr", value: 45 },
    { month: "May", value: 55 },
    { month: "Jun", value: 75 },
  ];

  const statusData = [
    { name: "Approved", value: 180, count: "180 (73%)", color: "#22c55e" },
    { name: "Pending", value: 32, count: "32 (13%)", color: "#eab308" },
    { name: "Rejected", value: 33, count: "33 (14%)", color: "#ef4444" },
  ];

  const workflows = [
    {
      id: "WF-101",
      title: "Leave Request",
      user: "John Doe",
      initials: "JD",
      avatarBg: "#eff6ff",
      avatarColor: "#2563eb",
      status: "Pending",
      time: "2 hours ago",
    },
    {
      id: "WF-102",
      title: "Budget Approval",
      user: "Sarah Smith",
      initials: "SS",
      avatarBg: "#f5f3ff",
      avatarColor: "#7c3aed",
      status: "Approved",
      time: "1 day ago",
    },
    {
      id: "WF-103",
      title: "Hiring Request",
      user: "Michael Brown",
      initials: "MB",
      avatarBg: "#ecfdf5",
      avatarColor: "#059669",
      status: "Under Review",
      time: "2 days ago",
    },
    {
      id: "WF-104",
      title: "Travel Reimbursement",
      user: "Emily Johnson",
      initials: "EJ",
      avatarBg: "#e0f2fe",
      avatarColor: "#0284c7",
      status: "Rejected",
      time: "3 days ago",
    },
  ];

  const getStatusStyles = (status) => {
    switch (status) {
      case "Approved":
        return { color: "#16a34a", bgcolor: "#dcfce7", border: "1px solid #bbf7d0" };
      case "Rejected":
        return { color: "#dc2626", bgcolor: "#fee2e2", border: "1px solid #fecaca" };
      case "Pending":
        return { color: "#b45309", bgcolor: "#fef3c7", border: "1px solid #fde68a" };
      default:
        return { color: "#2563eb", bgcolor: "#eff6ff", border: "1px solid #bfdbfe" };
    }
  };

  return (
    <MainLayout>
     <Box
  sx={{
    width: "100%",
    maxWidth: "none",
    display: "flex",
    flexDirection: "column",
    gap: 4,
  }}
>
        
        {/* HEADER AREA WITH FILTER */}
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Box>
            <Typography variant="h5" fontWeight="700" mb={0.5} sx={{ color: "#1e293b" }}>
              Welcome back, Admin! 👋
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ color: "#64748b" }}>
              Here's what's happening with your workflows today.
            </Typography>
          </Box>
          <Button 
            variant="outlined" 
            size="small" 
            startIcon={<CalendarToday sx={{ fontSize: 14 }} />} 
            endIcon={<ChevronRight sx={{ transform: "rotate(90deg)", fontSize: 14 }} />}
            sx={{ 
              textTransform: "none", 
              borderColor: "#e2e8f0", 
              color: "#1e293b", 
              fontWeight: 600, 
              borderRadius: 2.5, 
              bgcolor: "#fff", 
              px: 2, 
              py: 1 
            }}
          >
            May 24 – Jun 23, 2024
          </Button>
        </Stack>

        {/* OVERVIEW STATS GRID (SPANS CARDS BEAUTIFULLY) */}
        <Grid container spacing={3}>
          {stats.map((item) => (
            <Grid item xs={12} sm={6} md={3} key={item.title}>
              <Card sx={{ borderRadius: 3.5, boxShadow: "none", border: "1px solid #e2e8f0", bgcolor: "#fff" }}>
                <CardContent sx={{ p: 3, "&:last-child": { pb: 3 } }}>
                  <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                    <Box>
                      <Typography variant="caption" fontWeight="600" color="#64748b" display="block" mb={1}>
                        {item.title}
                      </Typography>
                      <Typography variant="h4" fontWeight="700" sx={{ mb: 0.5, color: "#0f172a", letterSpacing: "-1px" }}>
                        {item.value}
                      </Typography>
                      <Typography variant="caption" display="block" color="#94a3b8" mb={1.5}>
                        {item.subtext}
                      </Typography>
                      <Typography variant="caption" fontWeight="600" sx={{ color: item.growthColor }}>
                        {item.growth}
                      </Typography>
                    </Box>
                    <Avatar sx={{ bgcolor: item.bgColor, width: 44, height: 44, borderRadius: 2.5 }}>
                      {item.icon}
                    </Avatar>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* CHARTS GRAPH SYSTEM */}
        <Grid container spacing={3}>
          {/* Trend Card */}
          <Grid item xs={12} lg={8}>
            <Card sx={{ borderRadius: 3.5, boxShadow: "none", border: "1px solid #e2e8f0", height: 420, bgcolor: "#fff" }}>
              <CardContent sx={{ p: 3 }}>
                <Stack direction="row" justifyContent="space-between" alignItems="center" mb={3}>
                  <Typography variant="subtitle1" fontWeight="700" color="#1e293b">
                    Approval Trends
                  </Typography>
                  <Button variant="outlined" size="small" endIcon={<ChevronRight sx={{ transform: "rotate(90deg)", fontSize: 12 }} />} sx={{ textTransform: "none", color: "#64748b", borderColor: "#e2e8f0", borderRadius: 2, fontSize: "0.75rem", px: 1.5 }}>
                    This Quarter
                  </Button>
                </Stack>
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={trendData} barSize={32}>
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#94a3b8", fontSize: 12 }} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: "#94a3b8", fontSize: 12 }} domain={[0, 80]} ticks={[0, 20, 40, 60, 80]} />
                    <Tooltip cursor={{ fill: "transparent" }} />
                    <Bar dataKey="value" fill="url(#barGradient)" radius={[6, 6, 0, 0]}>
                      <defs>
                        <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#3b82f6" />
                          <stop offset="100%" stopColor="#60a5fa" />
                        </linearGradient>
                      </defs>
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Grid>

          {/* Pie Distribution Card */}
          <Grid item xs={12} lg={5}>
            <Card sx={{ borderRadius: 3.5, boxShadow: "none", border: "1px solid #e2e8f0", height: 360, bgcolor: "#fff" }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="subtitle1" fontWeight="700" color="#1e293b" mb={3}>
                  Workflow Status
                </Typography>
                <Stack direction="row" alignItems="center" justifyContent="space-between" height={240}>
                  <Box width="50%" height="100%">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={statusData} dataKey="value" innerRadius={58} outerRadius={78} paddingAngle={0}>
                          {statusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                  <Box width="50%" pl={2}>
                    <Stack spacing={2}>
                      {statusData.map((item) => (
                        <Stack key={item.name} direction="row" alignItems="center" justifyContent="space-between">
                          <Stack direction="row" alignItems="center" spacing={1.2}>
                            <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: item.color }} />
                            <Typography variant="body2" fontWeight="500" color="#64748b">{item.name}</Typography>
                          </Stack>
                          <Typography variant="body2" fontWeight="600" color="#1e293b">{item.count}</Typography>
                        </Stack>
                      ))}
                      <Box sx={{ borderTop: "1px solid #f1f5f9", pt: 2, mt: 0.5, display: "flex", alignItems: "center", gap: 1 }}>
                        <Box sx={{ width: 20, height: 20, bgcolor: "#ede9fe", borderRadius: 0.8, display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <Assignment sx={{ width: 12, height: 12, color: "#7c3aed" }} />
                        </Box>
                        <Typography variant="caption" fontWeight="600" color="#64748b">Total Workflows: 245</Typography>
                      </Box>
                    </Stack>
                  </Box>
                </Stack>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* WORKFLOW DATA RECORDS TABLE */}
        <Card sx={{ borderRadius: 3.5, boxShadow: "none", border: "1px solid #e2e8f0", bgcolor: "#fff", width: "100%" }}>
          <CardContent sx={{ p: 3 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="subtitle1" fontWeight="700" color="#1e293b">
                Recent Workflows
              </Typography>
              <Button size="small" variant="outlined" endIcon={<ChevronRight sx={{ fontSize: 14 }} />} sx={{ textTransform: "none", color: "#475569", borderColor: "#e2e8f0", fontWeight: 600, borderRadius: 2, px: 2, py: 0.6 }}>
                View All
              </Button>
            </Stack>

            {workflows.map((item) => {
              const chipStyle = getStatusStyles(item.status);
              return (
                <Box
                  key={item.id}
                  sx={{
                    display: "grid",
                    gridTemplateColumns: "1.5fr 1fr 1fr 1fr",
                    alignItems: "center",
                    py: 2.2,
                    borderBottom: "1px solid #f1f5f9",
                    "&:last-child": { borderBottom: "none" },
                  }}
                >
                  <Stack direction="row" spacing={2} alignItems="center">
                    <Box sx={{ p: 1.2, bgcolor: "#f1f5f9", borderRadius: 2, display: "flex", alignSelf: "center", border: "1px solid #e2e8f0" }}>
                      <Assignment sx={{ color: "#3b82f6", width: 18, height: 18 }} />
                    </Box>
                    <Box>
                      <Typography variant="body2" fontWeight="600" color="#1e293b">
                        {item.title}
                      </Typography>
                      <Typography variant="caption" color="#94a3b8">
                        {item.id}
                      </Typography>
                    </Box>
                  </Stack>

                  <Stack direction="row" spacing={1.5} alignItems="center">
                    <Avatar sx={{ bgcolor: item.avatarBg, color: item.avatarColor, width: 30, height: 30, fontSize: 11, fontWeight: 700 }}>
                      {item.initials}
                    </Avatar>
                    <Box>
                      <Typography variant="caption" color="#94a3b8" display="block" sx={{ lineHeight: 1 }}>Requested by</Typography>
                      <Typography variant="body2" fontWeight="500" color="#475569">{item.user}</Typography>
                    </Box>
                  </Stack>

                  <Stack direction="row" alignItems="center" spacing={0.8} sx={{ color: "#94a3b8" }}>
                    <AccessTime sx={{ width: 16, height: 16 }} />
                    <Typography variant="body2" color="#64748b">
                      {item.time}
                    </Typography>
                  </Stack>

                  <Box sx={{ justifySelf: "end" }}>
                    <Chip
                      label={item.status}
                      size="small"
                      sx={{
                        fontWeight: "600",
                        fontSize: "0.75rem",
                        height: 26,
                        color: chipStyle.color,
                        bgcolor: chipStyle.bgcolor,
                        border: chipStyle.border,
                        borderRadius: 2,
                        "& .MuiChip-label": { px: 1.8 }
                      }}
                    />
                  </Box>
                </Box>
              );
            })}
          </CardContent>
        </Card>
      </Box>
    </MainLayout>
  );
}

export default Dashboard;