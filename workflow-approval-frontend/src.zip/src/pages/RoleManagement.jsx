import React from "react";
import {
  Typography,
  Grid,
  Card,
  CardContent,
} from "@mui/material";

import MainLayout from "../layouts/MainLayout";

function RoleManagement() {
  const roles = [
    "Admin",
    "HR Manager",
    "Reviewer",
    "Finance Manager",
    "Employee",
  ];

  return (
    <MainLayout>
      <Typography variant="h4" fontWeight="bold" mb={3}>
        Role Management
      </Typography>

      <Grid container spacing={3}>
        {roles.map((role) => (
          <Grid item xs={12} md={4} key={role}>
            <Card>
              <CardContent>
                <Typography
                  variant="h6"
                  fontWeight="bold"
                >
                  {role}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </MainLayout>
  );
}

export default RoleManagement;